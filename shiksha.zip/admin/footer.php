<div class="pull-right">
		<footer>
           <p>Shiksha The Virtual Classroom</p>
           <!-- <p>Programmed by: Techtheories</p> -->
        <footer>
</div>