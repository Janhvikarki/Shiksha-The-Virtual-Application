				
								<div class="row-fluid">

						<div class="span12">
						
						</div>	
													
							</div>
							<div class="row-fluid">

						<div class="span4">
						<img class="index_logo" src="admin/images/Logo.gif">
						</div>	
						<div class="span8">
						
								<div class="title">
							<p class="chmsc">MVPS's R.S.M Poly - Nashik</p>
							<h3>

							<p>E - Learning Portal</p>
						
							</h3>		
						</div>
			
						</div>							
							</div>
				
				<div class="row-fluid">

						<div class="span12">
						<br>
								<div class="motto">
												<p>Shiksha EXCELS:</p>
												<p>Excellence, Competence and Educational</p>
												<p>Leadership in Science and Technology</p>
								</div>		
						</div>		
				</div>