<center>
		<footer>
		
		<p>Shiksha The Virtual Classroom</p>
			<!-- <p>Programmed by: Techtheories</p> -->
		</footer>
</center>

